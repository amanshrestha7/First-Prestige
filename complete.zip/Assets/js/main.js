$(document).ready(function() {

            $('body').scrollspy({ target: '.header-wrap', offset: 115})


            $("#sticker").sticky({topSpacing:0});
            //Chevron-down slide animation
            // $("#top-header a").click(function(e) {
            //     e.preventDefault();

            //     var target = $(this).attr("href");
            //     $('html, body').animate({
            //         scrollTop: $(target).offset().top-$('.header-wrap').outerHeight(),
            //     }, 400);
            // });





            function toggler(){
                 if($(window).width() <768){
                  $(document).on('click','#bs-example-navbar-collapse-2 ul li a', function(){
                    $('.navbar-toggle').click(); //bootstrap 3.x by Richard
                });
                 }
            }

            toggler();
                $(window).resize(function(){
                 toggler();
                });

            $(".navbar-nav li a").click(function(e) {
                e.preventDefault();

                var target = $(this).attr("href");
                $('html, body').animate({
                    scrollTop: $(target).offset().top-$('.header-wrap').outerHeight(true),
                }, 400);

            });


            //for tab collapse...
            $('#myTabs a').click(function (e) {
                e.preventDefault()
                $(this).tab('show')
            })

            //Display content on click(who we are section)
            
            // Call Gridder
            $(function() {

            // Call Gridder
            $('.gridder').gridderExpander({
                scroll: false,
                scrollOffset: 0,
                scrollTo: "panel",                  // panel or listitem
                animationSpeed: 400,
                animationEasing: "easeInOutExpo",
                showNav: true,                      // Show Navigation
                nextText: false,                   // Next button text
                prevText: false,               // Previous button text
                closeText: false,                 // Close button text
                onStart: function(){
                    //Gridder Inititialized
                },
                onContent: function(){
                    //Gridder Content Loaded
                },
                onClosed: function(){
                    //Gridder Closed
                }
            });

        });
});